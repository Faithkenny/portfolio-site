import { useEffect, useState } from 'react';
import './App.css';

// Libraries icons (outline style)
const LibrariesIcons = () => (
  <>
    {/* Left side icons */}
    <div className="icon-item left-1">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-8 h-8">
        <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
      </svg>
    </div>
    <div className="icon-item left-2">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-8 h-8">
        <circle cx="12" cy="8" r="4" />
        <path d="M4 20C4 16.6863 6.68629 14 10 14H14C17.3137 14 20 16.6863 20 20" />
      </svg>
    </div>
    <div className="icon-item left-3">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-8 h-8">
        <path d="M3 9.5L12 3L21 9.5V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9.5Z" />
        <path d="M9 22V12H15V22" />
      </svg>
    </div>
    <div className="icon-item left-4">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-8 h-8">
        <circle cx="12" cy="12" r="10" />
        <path d="M16 8C15.2 8 14.5 8.2 13.8 8.6C13.1 9 12.6 9.5 12.2 10.2C11.8 10.9 11.6 11.6 11.6 12.4V16" />
        <path d="M12 16H16" />
        <path d="M12 12H14" />
      </svg>
    </div>
    {/* Right side icons */}
    <div className="icon-item right-1">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-8 h-8">
        <circle cx="12" cy="12" r="10" />
        <path d="M8 14C8 14 9.5 16 12 16C14.5 16 16 14 16 14" />
        <circle cx="9" cy="9" r="1" fill="currentColor" />
        <circle cx="15" cy="9" r="1" fill="currentColor" />
      </svg>
    </div>
    <div className="icon-item right-2">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-8 h-8">
        <path d="M21 11.5C21.0034 12.8199 20.6951 14.1219 20.1 15.3C19.3944 16.7118 18.3098 17.8992 16.9674 18.7293C15.6251 19.5594 14.0782 19.9994 12.5 20C11.1801 20.0035 9.87812 19.6951 8.7 19.1L3 21L4.9 15.3C4.30493 14.1219 3.99656 12.8199 4 11.5C4.00061 9.92179 4.44061 8.37488 5.27072 7.03258C6.10083 5.69028 7.28825 4.6056 8.7 3.90003C9.87812 3.30496 11.1801 2.99659 12.5 3.00003H13C15.0843 3.11502 17.053 3.99479 18.5291 5.47089C20.0052 6.94699 20.885 8.91568 21 11V11.5Z" />
      </svg>
    </div>
    <div className="icon-item right-3">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-8 h-8">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15C19.7 14.3 20 13.7 20 13C20 12.3 19.7 11.7 19.4 11L21 9.4C21.3 9.1 21.4 8.7 21.2 8.3L20.2 6.3C20 5.9 19.6 5.7 19.2 5.8L17.1 6.4C16.1 5.7 15.1 5.2 14 5V3C14 2.4 13.6 2 13 2H11C10.4 2 10 2.4 10 3V5C8.9 5.2 7.9 5.7 6.9 6.4L4.8 5.8C4.4 5.7 4 5.9 3.8 6.3L2.8 8.3C2.6 8.7 2.7 9.1 3 9.4L4.6 11C4.3 11.7 4 12.3 4 13C4 13.7 4.3 14.3 4.6 15L3 16.6C2.7 16.9 2.6 17.3 2.8 17.7L3.8 19.7C4 20.1 4.4 20.3 4.8 20.2L6.9 19.6C7.9 20.3 8.9 20.8 10 21V23C10 23.6 10.4 24 11 24H13C13.6 24 14 23.6 14 23V21C15.1 20.8 16.1 20.3 17.1 19.6L19.2 20.2C19.6 20.3 20 20.1 20.2 19.7L21.2 17.7C21.4 17.3 21.3 16.9 21 16.6L19.4 15Z" />
      </svg>
    </div>
    <div className="icon-item right-4">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-8 h-8">
        <path d="M19 21L12 16L5 21V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H17C17.5304 3 18.0391 3.21071 18.4142 3.58579C18.7893 3.96086 19 4.46957 19 5V21Z" />
      </svg>
    </div>
  </>
);

// Plugins icons (dark card style with colorful elements)
const PluginsIcons = () => (
  <>
    {/* Left side plugin cards */}
    <div className="plugin-card left-1">
      <div className="w-10 h-10 rounded-xl bg-[#1a1a2e] border border-[#2a2a3e] flex items-center justify-center">
        <div className="w-5 h-5 rounded-full border-2 border-cyan-400" />
      </div>
    </div>
    <div className="plugin-card left-2">
      <div className="w-10 h-10 rounded-xl bg-[#1a1a2e] border border-[#2a2a3e] flex items-center justify-center">
        <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none">
          <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2Z" fill="#4ade80" fillOpacity="0.3" stroke="#4ade80" strokeWidth="1.5"/>
          <circle cx="9" cy="10" r="2" fill="#4ade80"/>
          <circle cx="15" cy="10" r="2" fill="#4ade80"/>
          <path d="M9 15C9 15 10.5 17 12 17C13.5 17 15 15 15 15" stroke="#4ade80" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      </div>
    </div>
    <div className="plugin-card left-3">
      <div className="w-12 h-14 rounded-xl bg-[#1a1a2e] border border-[#2a2a3e] flex flex-col items-center justify-center gap-1.5 p-2">
        <div className="w-full h-2 rounded-full bg-pink-400/80" />
        <div className="w-full h-2 rounded-full bg-purple-500/80" />
      </div>
    </div>
    <div className="plugin-card left-4">
      <div className="w-10 h-10 rounded-xl bg-[#1a1a2e] border border-[#2a2a3e] flex items-center justify-center">
        <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none">
          <circle cx="12" cy="12" r="10" stroke="#f472b6" strokeWidth="1.5"/>
          <text x="12" y="16" textAnchor="middle" fill="#f472b6" fontSize="10" fontFamily="sans-serif">@</text>
        </svg>
      </div>
    </div>
    {/* Right side plugin cards */}
    <div className="plugin-card right-1">
      <div className="w-10 h-10 rounded-xl bg-[#1a1a2e] border border-[#2a2a3e] flex items-center justify-center">
        <span className="text-gray-400 text-sm font-medium">Aa</span>
      </div>
    </div>
    <div className="plugin-card right-2">
      <div className="w-12 h-14 rounded-xl bg-[#1a1a2e] border border-[#2a2a3e] flex flex-col items-center justify-center gap-1.5 p-2">
        <div className="flex items-center gap-1.5 w-full">
          <div className="w-2 h-2 rounded-sm bg-pink-400 rotate-45" />
          <div className="flex-1 h-2 rounded-full bg-pink-400/80" />
        </div>
        <div className="flex items-center gap-1.5 w-full">
          <div className="w-2 h-2 rounded-sm bg-purple-500 rotate-45" />
          <div className="flex-1 h-2 rounded-full bg-purple-500/80" />
        </div>
      </div>
    </div>
    <div className="plugin-card right-3">
      <div className="w-10 h-10 rounded-xl bg-[#1a1a2e] border border-[#2a2a3e] flex items-center justify-center">
        <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="#60a5fa" strokeWidth="1.5">
          <path d="M4 19.5C4 18.837 4.26339 18.2011 4.73223 17.7322C5.20107 17.2634 5.83696 17 6.5 17H20" />
          <path d="M6.5 2H20V22H6.5C5.83696 22 5.20107 21.7366 4.73223 21.2678C4.26339 20.7989 4 20.163 4 19.5V4.5C4 3.83696 4.26339 3.20107 4.73223 2.73223C5.20107 2.26339 5.83696 2 6.5 2Z" />
        </svg>
      </div>
    </div>
  </>
);

// Icon sets (colorful gradient app icons)
const IconSetsIcons = () => (
  <>
    {/* Left side colorful icons */}
    <div className="colorful-icon left-1">
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-400 via-purple-500 to-blue-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
        <span className="text-white font-bold text-lg">M</span>
      </div>
    </div>
    <div className="colorful-icon left-2">
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-gray-800 to-black flex items-center justify-center shadow-lg">
        <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center">
          <svg viewBox="0 0 24 24" className="w-4 h-4 text-white" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M5 12H19M19 12L12 5M19 12L12 19" />
          </svg>
        </div>
      </div>
    </div>
    <div className="colorful-icon left-3">
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
        <div className="grid grid-cols-2 gap-1">
          <div className="w-3 h-4 rounded-sm bg-white/90" />
          <div className="w-3 h-4 rounded-sm bg-white/90" />
          <div className="w-3 h-3 rounded-sm bg-white/90" />
          <div className="w-3 h-3 rounded-sm bg-white/90" />
        </div>
      </div>
    </div>
    {/* Right side colorful icons */}
    <div className="colorful-icon right-1">
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-400 via-blue-400 to-green-400 flex items-center justify-center shadow-lg shadow-cyan-500/30">
        <svg viewBox="0 0 24 24" className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="3">
          <path d="M5 13L9 17L19 7" />
        </svg>
      </div>
    </div>
    <div className="colorful-icon right-2">
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-300 via-purple-400 to-cyan-400 flex items-center justify-center shadow-lg">
        <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
          <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="3" y="3" width="18" height="18" rx="4" />
            <path d="M8 12C8 12 9.5 14 12 14C14.5 14 16 12 16 12" />
            <circle cx="9" cy="9" r="1" fill="currentColor" />
            <circle cx="15" cy="9" r="1" fill="currentColor" />
          </svg>
        </div>
      </div>
    </div>
    <div className="colorful-icon right-3">
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
        <svg viewBox="0 0 24 24" className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M20.24 12.24C21.3658 11.1142 21.9983 9.58718 21.9983 7.995C21.9983 6.40282 21.3658 4.87575 20.24 3.75C19.1142 2.62425 17.5872 1.99167 15.995 1.99167C14.4028 1.99167 12.8758 2.62425 11.75 3.75L5 10.5V19H13.5L20.24 12.24Z" />
          <path d="M16 8L2 22" />
          <path d="M17.5 15H9" />
        </svg>
      </div>
    </div>
  </>
);

function App() {
  const [phase, setPhase] = useState(0); // 0: libraries, 1: plugins, 2: icon sets

  useEffect(() => {
    const interval = setInterval(() => {
      setPhase((prev) => (prev + 1) % 3);
    }, 2000); // Change every 2 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1d29] via-[#1e2330] to-[#1a1d29] flex items-center justify-center relative overflow-hidden">
      {/* Subtle radial gradient overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(59,130,246,0.05)_0%,_transparent_70%)]" />
      
      {/* Icon container */}
      <div className="relative w-full max-w-5xl h-[400px] flex items-center justify-center">
        {/* Libraries icons */}
        <div className={`icon-set ${phase === 0 ? 'active' : 'inactive'}`}>
          <LibrariesIcons />
        </div>
        
        {/* Plugins icons */}
        <div className={`icon-set ${phase === 1 ? 'active' : 'inactive'}`}>
          <PluginsIcons />
        </div>
        
        {/* Icon sets */}
        <div className={`icon-set ${phase === 2 ? 'active' : 'inactive'}`}>
          <IconSetsIcons />
        </div>

        {/* Center text */}
        <div className="relative z-10 text-center px-4">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-semibold text-white leading-relaxed">
            Discover community-made{' '}
            <span className={`keyword ${phase === 0 ? 'highlight' : ''}`}>libraries</span>,{' '}
            <span className={`keyword ${phase === 1 ? 'highlight' : ''}`}>plugins</span>,{' '}
            <span className={`keyword ${phase === 2 ? 'highlight' : ''}`}>icon sets</span>, and more
          </h2>
        </div>
      </div>
    </div>
  );
}

export default App;
